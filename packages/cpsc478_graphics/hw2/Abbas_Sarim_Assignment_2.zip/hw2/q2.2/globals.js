
// If you are have a local web server keep the following line uncommented
NVMC.resource_path = "../../media/"


// If you do not  have a local web server and just open the html with a browser,
// then uncomment the following line
//NVMC.resource_path = "http://vcg.isti.cnr.it/~nvmc/media_remote/"