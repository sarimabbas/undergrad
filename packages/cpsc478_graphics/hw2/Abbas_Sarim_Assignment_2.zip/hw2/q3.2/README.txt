You can set n in line 112. 
The function signature is fAlt(Z, n)