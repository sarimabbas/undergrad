/*
 * Serializer.cpp
 *
 *  Created on: Nov 11, 2018
 *      Author: mike
 */

#include "Serial.hpp"

// Initialize Serializer static variable
Serial* Serial::Sobj = nullptr;
